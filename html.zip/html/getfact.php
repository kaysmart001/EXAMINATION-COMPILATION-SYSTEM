<!doctype html>
<html lang="en">
<html>
<head>
<title>TEACHERS</title>
</head>
  <style type= "text/css">
  
    #header{
    background-color: pink;
    width:1340px;
    height: 80px;
    padding: 2px;
    }
    body{
    background-image: url(ideal.jpg);
    }
    h1{
    font-family: Times New Roman;
    font-size: 40px;
    text-align: center;
    color: black;
    }
    h3{
    font-family: Times New Roman;
    font-size: 20px;
    text-align: center;
    color: black;
    }
    table{
    border: 1px solid black;
    border-radius: 10px;
    padding: 2px;
    background-color: white;
    width: 500px;
    height: 300px;
    }
    a:link{
    color: black;
    text-decoration: none;
    }
    a:visited{
    color: black;
    }
    a:active{
    color: black;
    }
    a:hover{
    color: gray;
  }
</style>

<body> 
<div id="header">

<h1>TEACHERS SYSTEM</h1>
</div>
<br>
<br>
<br>
<br>
<br>
<center>
<table>
  <tr>
  <td>
    <h3><a href="permit.html">ADD NEW QUESTIONS</a></h3>
    <br>
    <h3><a href="grade.html">CHECK STUDENT PERFORMANCE</a></h3>
    <br>
    
  </td>
  </tr>
</table>
</center>
</body>


</html>